Earth 2150: The Moon Project - Proxy Launcher

Author:
Animal

-----------------------------------------------------------------------------------------------
--- Install -----------------------------------------------------------------------------------

1. Copy the "launcher" or "launcherShell" (*1) folder and all its contents
   into a location that is not the installation directory of the game, for example:
   > C:\Users\<USERNAME>\Documents\My Games\Earth 2150 The Moon Project Launcher\

   [!!] DO NOT extract the files (!) into the root directory of the game

   Directory hierarchy should look like this:
   > C:\Users\<USERNAME>\Documents\My Games\Earth 2150 The Moon Project Launcher\TheMoonProject.exe
   > C:\Users\<USERNAME>\Documents\My Games\Earth 2150 The Moon Project Launcher\WDFiles\InterfaceEx.wd

2. Start GameRanger

3. Open Edit > Options > Games

4. Select the game from the list

5. Click Browse... and navigate to TheMoonProject.exe in launcher directory, for example:
   > C:\Users\<USERNAME>\Documents\My Games\Earth 2150 The Moon Project Launcher\TheMoonProject.exe



(*1) Whether or not you can use "launcher" or "launcherShell" depends on your system.
     Some systems don't work correctly with one or the other.


-----------------------------------------------------------------------------------------------
--- Customisations ----------------------------------------------------------------------------

+ Edit launcher\commandline.txt to append custom command line arguments to executable.


-----------------------------------------------------------------------------------------------
--- Changelog ---------------------------------------------------------------------------------

v0.7:
- Beta release