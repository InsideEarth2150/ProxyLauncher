Earth 2150: The Moon Project - Proxy Launcher

Author:
Animal

-----------------------------------------------------------------------------------------------
--- Install -----------------------------------------------------------------------------------

1. Copy the "launcher" or "launcherShell" (*1) folder and all its contents
   into the game root install directory, for example:
   > C:\Program Files (x86)\Topware\Earth 2150 The Moon Project

   [!!] DO NOT extract the files (!) into the root directory of the game

   Directory hierarchy should look like this:
   > C:\Program Files (x86)\Topware\Earth 2150 The Moon Project\launcher\
   > C:\Program Files (x86)\Topware\Earth 2150 The Moon Project\launcherShell\

2. Start GameRanger

3. Open Edit > Options > Games

4. Select the game from the list

5. Click Browse... and navigate to TheMoonProject.exe in launcher directory, for example:
   > C:\Program Files (x86)\Topware\Earth 2150 The Moon Project\launcher\TheMoonProject.exe



(*1) Whether or not you can use "launcher" or "launcherShell" depends on your system.
     Some systems don't work correctly with one or the other.


-----------------------------------------------------------------------------------------------
--- Customisations ----------------------------------------------------------------------------

+ Edit launcher\commandline.txt to append custom command line arguments to executable.


-----------------------------------------------------------------------------------------------
--- Changelog ---------------------------------------------------------------------------------

v0.7:
- Beta release