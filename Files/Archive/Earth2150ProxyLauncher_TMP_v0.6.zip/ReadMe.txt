Earth 2150 Proxy Launcher for The Moon Project

Authors:
Animal & Guardian

-----------------------------------------------------------------------------------------------
--- Install -----------------------------------------------------------------------------------

1. Copy the "launcher" folder and all its contents
   to any location outside of the Steam folder, for example:
   > C:\Users\<USERNAME>\Documents\My Games\Earth 2150 The Moon Project

   [!!] DO NOT extract the files (!) into the root directory of the game

   Directory hierarchy should look like this:
   > C:\Users\<USERNAME>\Documents\My Games\Earth 2150 The Moon Project\launcher\

2. Start GameRanger

3. Open Edit > Options > Games

4. Select the game from the list

5. Click Browse... and navigate to TheMoonProject.exe in launcher directory, for example:
   > C:\Users\<USERNAME>\Documents\My Games\Earth 2150 The Moon Project\launcher\TheMoonProject.exe


-----------------------------------------------------------------------------------------------
--- Changelog ---------------------------------------------------------------------------------

v0.6:
- Beta Release